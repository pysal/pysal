"""
Set SKIP to True to skip any tests in this directory with the skip decorator

To run all tests set SKIP=False
"""
SKIP=True
