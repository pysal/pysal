giddy.directional.Rose
======================

.. currentmodule:: giddy.directional

.. automethod:: Rose.plot_vectors


   
   
   