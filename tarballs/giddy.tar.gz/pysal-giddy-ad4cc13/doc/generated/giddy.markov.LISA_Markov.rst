giddy.markov.LISA\_Markov
=========================

.. currentmodule:: giddy.markov

.. autoclass:: LISA_Markov

   
   .. automethod:: __init__


   