giddy.markov.kullback
=====================

.. currentmodule:: giddy.markov

.. autofunction:: kullback