giddy.mobility.markov\_mobility
===============================

.. currentmodule:: giddy.mobility

.. autofunction:: markov_mobility