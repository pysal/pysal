giddy.rank.Tau\_Local\_Neighbor
===============================

.. currentmodule:: giddy.rank

.. autoclass:: Tau_Local_Neighbor

   
   .. automethod:: __init__

   
   

   
   
   