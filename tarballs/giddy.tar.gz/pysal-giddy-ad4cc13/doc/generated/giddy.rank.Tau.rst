giddy.rank.Tau
==============

.. currentmodule:: giddy.rank

.. autoclass:: Tau

   
   .. automethod:: __init__


   

   
   
   