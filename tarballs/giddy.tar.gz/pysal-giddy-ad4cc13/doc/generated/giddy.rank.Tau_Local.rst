giddy.rank.Tau\_Local
=====================

.. currentmodule:: giddy.rank

.. autoclass:: Tau_Local

   
   .. automethod:: __init__


   

   
   
   