giddy.ergodic.steady\_state
===========================

.. currentmodule:: giddy.ergodic

.. autofunction:: steady_state