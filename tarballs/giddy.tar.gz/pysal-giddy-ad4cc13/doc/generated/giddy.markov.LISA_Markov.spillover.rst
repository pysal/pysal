giddy.markov.LISA\_Markov
=========================

.. currentmodule:: giddy.markov
   
.. automethod:: LISA_Markov.spillover


   
   