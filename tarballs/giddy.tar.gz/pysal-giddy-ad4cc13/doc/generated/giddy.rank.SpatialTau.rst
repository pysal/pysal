giddy.rank.SpatialTau
=====================

.. currentmodule:: giddy.rank

.. autoclass:: SpatialTau

   
   .. automethod:: __init__


   
   

   
   
   