giddy.markov.Markov
===================

.. currentmodule:: giddy.markov

.. autoclass:: Markov

   
   .. automethod:: __init__


   