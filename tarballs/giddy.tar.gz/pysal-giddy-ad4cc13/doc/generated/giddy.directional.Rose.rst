giddy.directional.Rose
======================

.. currentmodule:: giddy.directional

.. autoclass:: Rose

   
   .. automethod:: __init__



   
   
   