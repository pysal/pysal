giddy.markov.homogeneity
========================

.. currentmodule:: giddy.markov

.. autofunction:: homogeneity