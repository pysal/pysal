giddy.rank.Tau\_Local\_Neighborhood
===================================

.. currentmodule:: giddy.rank

.. autoclass:: Tau_Local_Neighborhood

   
   .. automethod:: __init__


   

   
   
   