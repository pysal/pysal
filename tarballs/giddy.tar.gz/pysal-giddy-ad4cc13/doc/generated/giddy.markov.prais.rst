giddy.markov.prais
==================

.. currentmodule:: giddy.markov

.. autofunction:: prais