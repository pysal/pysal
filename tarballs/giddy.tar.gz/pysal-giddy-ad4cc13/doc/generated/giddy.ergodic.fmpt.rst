giddy.ergodic.fmpt
==================

.. currentmodule:: giddy.ergodic

.. autofunction:: fmpt