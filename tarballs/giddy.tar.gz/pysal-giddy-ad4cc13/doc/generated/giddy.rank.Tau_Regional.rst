giddy.rank.Tau\_Regional
========================

.. currentmodule:: giddy.rank

.. autoclass:: Tau_Regional

   
   .. automethod:: __init__

   

   
   
   