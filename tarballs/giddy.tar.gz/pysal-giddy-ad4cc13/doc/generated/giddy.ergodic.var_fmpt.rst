giddy.ergodic.var\_fmpt
=======================

.. currentmodule:: giddy.ergodic

.. autofunction:: var_fmpt