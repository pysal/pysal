giddy.rank.Theta
================

.. currentmodule:: giddy.rank

.. autoclass:: Theta

   
   .. automethod:: __init__

   

   
   
   