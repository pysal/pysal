giddy.markov.Spatial\_Markov
============================

.. currentmodule:: giddy.markov

.. autoclass:: Spatial_Markov

   
   .. automethod:: __init__

   

   
   