giddy.directional.Rose
======================

.. currentmodule:: giddy.directional

.. automethod:: Rose.permute


   
   
   