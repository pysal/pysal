.. _general_examples:

giddy Gallery
=============


These examples illustrate some of the functionality provided in giddy.

Longer-form tutorials belong at XXX and can be submitted at XXX.

