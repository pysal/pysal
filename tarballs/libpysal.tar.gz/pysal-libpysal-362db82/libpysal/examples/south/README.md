south
=====

Homicides and selected socio-economic characteristics for Southern U.S. counties (subset of NCOVR national data set). Data for four decennial census years: 1960, 1970, 1980, 1990.
----------------------------------------------------------------------

* south.dbf: attribute data. (k=69)
* south.shp: Polygon shapefile. (n=1412)
* south.shx: spatial index.
* south_q.gal: queen contiguity weights in GAL format.
* south_queen.gal: queen contiguity weights in GAL format.
