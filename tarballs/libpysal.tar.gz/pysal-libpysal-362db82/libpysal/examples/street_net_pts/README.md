street_net_pts
==============

Street network points
---------------------

* street_net_pts.dbf: attribute data. (k=1)
* street_net_pts.prj: ESRI projection file.
* street_net_pts.qpj: QGIS projection file.
* street_net_pts.shp: Point shapefile. (n=303)
* street_net_pts.shx: spatial index.
