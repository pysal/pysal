columbus
========

Columbus neighborhood crime data 1980
-------------------------------------

* columbus.dbf: attribute data. (k=20)
* columbus.gal: queen contiguity file in GAL format.
* columbus.html: metadata.
* columbus.json: shape and attribute data file in JSON format.
* columbus.shp: Polygon shapefile. (n=49)
* columbus.shx: spatial index.

Anselin, Luc (1988). Spatial Econometrics. Boston, Kluwer Academic, Table 12.1, p. 189.