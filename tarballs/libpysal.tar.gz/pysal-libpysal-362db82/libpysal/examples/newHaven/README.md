newHaven
========

New Haven crime dataset Sept 2014
---------------------------------

* new_haven_merged.dbf: attribute data for New Haven crimes. (k=5)
* new_haven_merged.shp: Point shapefile. (n=3293)
* new_haven_merged.shx: spatial index.
* newhaven_nework.dbf: attribute data for New Haven street network. (k=6)
* newhaven_nework.prj: ESRI projection file.
* newhaven_nework.qpj: QGIS projection file.
* newhaven_nework.shp: Line shapefile. (n=1537)
* newhaven_nework.shx: spatial index.
