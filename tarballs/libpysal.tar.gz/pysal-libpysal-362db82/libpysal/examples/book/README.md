book
====

Synthetic data to illustrate spatial weights 
--------------------------------------------

* book.gal: rook contiguity weights in GAL format for regular lattice.
* book.txt: attribute data for regular lattice.

Source: Anselin, L. and S.J. Rey (in progress) Spatial Econometrics: Foundations.
