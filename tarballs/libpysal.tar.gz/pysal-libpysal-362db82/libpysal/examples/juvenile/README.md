juvenile
========

Residences of juvenile offenders in Cardiff, UK
-----------------------------------------------

* juvenile.dbf: attribute data. (k=3)
* juvenile.gwt: spatial weights in GWT format.
* juvenile.shp: Point shapefile. (n=168)
* juvenile.shx: spatial index.

Source: http://geodacenter.org/downloads/data-files/juvenile.zip
