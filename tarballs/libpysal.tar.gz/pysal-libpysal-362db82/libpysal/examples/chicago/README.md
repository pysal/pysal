chicago
=======

Chicago neighborhoods
--------------------

* Chicago77.dbf: attribute data. (k=11)
* Chicago77.shp: Polygon shapefile. (n=77)
* Chicago77.shx: spatial index.
