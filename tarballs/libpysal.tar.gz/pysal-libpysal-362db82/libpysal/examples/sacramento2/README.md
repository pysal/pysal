sacramento2
===========

2000 Census Tract Data for Sacramento MSA
-----------------------------------------

* sacramentot2.dbf: attribute data. (k=31)
* sacramentot2.gal: queen contiguity weights in GAL format.
* sacramentot2.sbn: spatial index.
* sacramentot2.sbx: spatial index.
* sacramentot2.shp: Polygon shapefile. (n=403)
* sacramentot2.shx: spatial index.

Source: US Census Bureau, 2000 Census (Summary File 3). Extracted from http://factfinder.census.gov in April 2004.