nat
===

US county homicides 1960-1990
-----------------------------

* NAT.dbf: attribute data for US county homicides. (k=69)
* NAT.shp: Polygon shapefile for US counties. (n=3085)
* NAT.shx: spatial index.
* nat.geojson: shape and attribute data in GeoJSON format.
* nat_queen.gal: queen contiguity weights in GAL format.
* nat_queen_old.gal: queen contiguity weights in GAL format using old polygon index.
* nat_trian_k20.kwt: kernel weights in KWT format.
* natregimes.dbf: attribute data for US county homicides with regimes assigned. (k=73)
* natregimes.shp: Polygon shapefile for US counties. (n=3085)
* natregimes.shx: spatial index.
