from .model import Upper_SMA, Base_Upper_SMA
