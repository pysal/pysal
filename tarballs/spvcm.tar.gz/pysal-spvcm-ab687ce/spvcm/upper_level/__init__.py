from .se import Upper_SE as SE
from .sma import Upper_SMA as SMA

del (se, sma)
