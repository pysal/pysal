from .model import SMASMA
