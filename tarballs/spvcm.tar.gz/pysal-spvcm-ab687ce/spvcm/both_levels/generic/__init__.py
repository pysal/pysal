from .model import Generic, Base_Generic
