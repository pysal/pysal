spglm.glm.GLMResults
====================

.. currentmodule:: spglm.glm

.. autoclass:: GLMResults

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~GLMResults.D2
      ~GLMResults.__init__
      ~GLMResults.adj_D2
      ~GLMResults.adj_pseudoR2
      ~GLMResults.aic
      ~GLMResults.bic
      ~GLMResults.bse
      ~GLMResults.conf_int
      ~GLMResults.cov_params
      ~GLMResults.deviance
      ~GLMResults.df_model
      ~GLMResults.df_resid
      ~GLMResults.initialize
      ~GLMResults.llf
      ~GLMResults.llnull
      ~GLMResults.normalized_cov_params
      ~GLMResults.null
      ~GLMResults.null_deviance
      ~GLMResults.pearson_chi2
      ~GLMResults.pseudoR2
      ~GLMResults.pvalues
      ~GLMResults.resid_anscombe
      ~GLMResults.resid_deviance
      ~GLMResults.resid_pearson
      ~GLMResults.resid_response
      ~GLMResults.resid_working
      ~GLMResults.scale
      ~GLMResults.tr_S
      ~GLMResults.tvalues
   
   

   
   
   .. rubric:: Attributes

   .. autosummary::
   
      ~GLMResults.use_t
   
   