__version__ = '1.0.6'

from . import glm
from . import family
from . import utils
from . import iwls
