__version__ = "1.0.0"

"""
:mod:`inequality` --- Spatial Inequality Analysis
=================================================

"""

from . import theil
from . import gini
