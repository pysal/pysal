inequality.gini.Gini
====================

.. currentmodule:: inequality.gini

.. autoclass:: Gini

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Gini.__init__
   
   

   
   
   