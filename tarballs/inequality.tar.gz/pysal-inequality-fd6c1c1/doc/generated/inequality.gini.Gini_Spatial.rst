inequality.gini.Gini\_Spatial
=============================

.. currentmodule:: inequality.gini

.. autoclass:: Gini_Spatial

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Gini_Spatial.__init__
   
   

   
   
   