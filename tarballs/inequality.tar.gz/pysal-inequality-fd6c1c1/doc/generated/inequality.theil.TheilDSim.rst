inequality.theil.TheilDSim
==========================

.. currentmodule:: inequality.theil

.. autoclass:: TheilDSim

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TheilDSim.__init__
   
   

   
   
   