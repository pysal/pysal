inequality.theil.TheilD
=======================

.. currentmodule:: inequality.theil

.. autoclass:: TheilD

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~TheilD.__init__
   
   

   
   
   