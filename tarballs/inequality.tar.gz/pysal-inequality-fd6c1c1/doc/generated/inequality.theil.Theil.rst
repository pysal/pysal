inequality.theil.Theil
======================

.. currentmodule:: inequality.theil

.. autoclass:: Theil

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Theil.__init__
   
   

   
   
   