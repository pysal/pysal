mgwr.kernels.adapt\_exp
=======================

.. currentmodule:: mgwr.kernels

.. autofunction:: adapt_exp