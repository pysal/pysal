mgwr.gwr.MGWRResults
====================

.. currentmodule:: mgwr.gwr

.. autoclass:: MGWRResults

   
   .. automethod:: __init__

   

   
   
   