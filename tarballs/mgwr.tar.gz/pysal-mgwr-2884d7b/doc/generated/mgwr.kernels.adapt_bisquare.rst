mgwr.kernels.adapt\_bisquare
============================

.. currentmodule:: mgwr.kernels

.. autofunction:: adapt_bisquare