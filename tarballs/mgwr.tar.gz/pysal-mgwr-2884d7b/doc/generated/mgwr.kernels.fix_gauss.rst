mgwr.kernels.fix\_gauss
=======================

.. currentmodule:: mgwr.kernels

.. autofunction:: fix_gauss