mgwr.kernels.fix\_bisquare
==========================

.. currentmodule:: mgwr.kernels

.. autofunction:: fix_bisquare