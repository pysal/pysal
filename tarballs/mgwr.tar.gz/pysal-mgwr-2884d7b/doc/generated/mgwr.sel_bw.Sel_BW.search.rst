mgwr.sel_bw.Sel_BW
====================

.. currentmodule:: mgwr.sel_bw

.. automethod:: Sel_BW.search


   