mgwr.kernels.adapt\_gauss
=========================

.. currentmodule:: mgwr.kernels

.. autofunction:: adapt_gauss