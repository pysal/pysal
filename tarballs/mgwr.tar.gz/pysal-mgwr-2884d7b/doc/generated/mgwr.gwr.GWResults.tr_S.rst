mgwr.gwr.GWRResults
===================

.. currentmodule:: mgwr.gwr

.. automethod:: GWRResults.tr_S


   