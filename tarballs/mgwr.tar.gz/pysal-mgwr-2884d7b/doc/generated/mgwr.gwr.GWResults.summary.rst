mgwr.gwr.GWRResults
===================

.. currentmodule:: mgwr.gwr

.. automethod:: GWRResults.summary


   