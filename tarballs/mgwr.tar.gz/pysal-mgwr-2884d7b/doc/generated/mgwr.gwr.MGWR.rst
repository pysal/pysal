mgwr.gwr.MGWR
=============

.. currentmodule:: mgwr.gwr

.. autoclass:: MGWR

   
   .. automethod:: __init__
