mgwr.utils.shift\_colormap
==========================

.. currentmodule:: mgwr.utils

.. autofunction:: shift_colormap