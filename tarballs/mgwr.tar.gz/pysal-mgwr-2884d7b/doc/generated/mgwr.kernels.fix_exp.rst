mgwr.kernels.fix\_exp
=====================

.. currentmodule:: mgwr.kernels

.. autofunction:: fix_exp