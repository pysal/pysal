mgwr.gwr.GWR
============

.. currentmodule:: mgwr.gwr

.. automethod:: GWR.predict


   