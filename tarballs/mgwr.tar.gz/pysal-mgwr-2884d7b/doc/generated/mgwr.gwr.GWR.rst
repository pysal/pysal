mgwr.gwr.GWR
============

.. currentmodule:: mgwr.gwr

.. autoclass:: GWR

   
   .. automethod:: __init__


   