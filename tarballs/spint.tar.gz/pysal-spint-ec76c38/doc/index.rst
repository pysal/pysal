.. documentation master file

SPatial INTeraction models (SPINT)

.. toctree::
   :hidden:
   :maxdepth: 3
   :caption: Contents:

   Installation <installation>
   API <api>
   References <references>


.. _PySAL: https://github.com/pysal/pysal
