spint.dispersion.phi\_disp
==========================

.. currentmodule:: spint.dispersion

.. autofunction:: phi_disp