spint.dispersion.alpha\_disp
============================

.. currentmodule:: spint.dispersion

.. autofunction:: alpha_disp