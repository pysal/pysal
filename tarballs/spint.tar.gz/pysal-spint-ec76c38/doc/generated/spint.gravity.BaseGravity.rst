spint.gravity.BaseGravity
=========================

.. currentmodule:: spint.gravity

.. autoclass:: BaseGravity

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~BaseGravity.SRMSE
      ~BaseGravity.SSI
      ~BaseGravity.__init__
      ~BaseGravity.fit
      ~BaseGravity.reshape
   
   

   
   
   