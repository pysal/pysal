spint.gravity.Doubly
====================

.. currentmodule:: spint.gravity

.. autoclass:: Doubly

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Doubly.SRMSE
      ~Doubly.SSI
      ~Doubly.__init__
      ~Doubly.fit
      ~Doubly.local
      ~Doubly.reshape
   
   

   
   
   