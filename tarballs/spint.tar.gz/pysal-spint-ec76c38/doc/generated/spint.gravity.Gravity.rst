spint.gravity.Gravity
=====================

.. currentmodule:: spint.gravity

.. autoclass:: Gravity

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Gravity.SRMSE
      ~Gravity.SSI
      ~Gravity.__init__
      ~Gravity.fit
      ~Gravity.local
      ~Gravity.reshape
   
   

   
   
   