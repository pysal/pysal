spint.gravity.Attraction
========================

.. currentmodule:: spint.gravity

.. autoclass:: Attraction

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Attraction.SRMSE
      ~Attraction.SSI
      ~Attraction.__init__
      ~Attraction.fit
      ~Attraction.local
      ~Attraction.reshape
   
   

   
   
   