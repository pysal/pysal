# Changes

Version 1.0.4 (2018-010-31)

We closed a total of 5 issues (enhancements and bug fixes) through 2 pull requests, since our last release on 2018-09-06.

## Issues Closed
  - pypi files do not include tests (#9)
  - Submodule (#14)
  - adapting spint to newest version of libpysal (#13)

## Pull Requests
  - Submodule (#14)
  - adapting spint to newest version of libpysal (#13)

The following individuals contributed to this release:

  - Taylor Oshan