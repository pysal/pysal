import datetime
Major = 1
Feature = 1
Bug = 0
version = '%d.%d.%d' % (Major, Feature, Bug)
stable_release_date = datetime.date(2018, 5, 17)
