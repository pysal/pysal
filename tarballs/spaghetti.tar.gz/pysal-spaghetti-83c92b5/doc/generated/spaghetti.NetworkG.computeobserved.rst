spaghetti.NetworkG.computeobserved
==================================

.. currentmodule:: spaghetti

.. automethod:: NetworkG.computeobserved