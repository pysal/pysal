spaghetti.NetworkK.setbounds
============================

.. currentmodule:: spaghetti

.. automethod:: NetworkK.setbounds