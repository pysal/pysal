spaghetti.NetworkF.computepermutations
======================================

.. currentmodule:: spaghetti

.. automethod:: NetworkF.computepermutations