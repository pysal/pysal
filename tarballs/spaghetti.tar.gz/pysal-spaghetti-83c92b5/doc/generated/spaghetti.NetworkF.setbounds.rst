spaghetti.NetworkF.setbounds
============================

.. currentmodule:: spaghetti

.. automethod:: NetworkF.setbounds