spaghetti.NetworkG.computepermutations
======================================

.. currentmodule:: spaghetti

.. automethod:: NetworkG.computepermutations