spaghetti.Network.distancebandweights
=====================================

.. currentmodule:: spaghetti

.. automethod:: Network.distancebandweights