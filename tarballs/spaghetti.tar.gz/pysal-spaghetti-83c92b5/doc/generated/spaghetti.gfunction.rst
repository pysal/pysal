spaghetti.gfunction
===================

.. currentmodule:: spaghetti

.. autofunction:: gfunction