spaghetti.NetworkG
==================

.. currentmodule:: spaghetti

.. autoclass:: NetworkG

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NetworkG.__init__
      ~NetworkG.computeenvelope
      ~NetworkG.computeobserved
      ~NetworkG.computepermutations
      ~NetworkG.setbounds
      ~NetworkG.validatedistribution
   
   

   
   
   