spaghetti.get\_neighbor\_distances
==================================

.. currentmodule:: spaghetti

.. autofunction:: get_neighbor_distances