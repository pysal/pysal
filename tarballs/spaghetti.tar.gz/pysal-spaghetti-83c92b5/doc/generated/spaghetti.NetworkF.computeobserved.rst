spaghetti.NetworkF.computeobserved
==================================

.. currentmodule:: spaghetti

.. automethod:: NetworkF.computeobserved