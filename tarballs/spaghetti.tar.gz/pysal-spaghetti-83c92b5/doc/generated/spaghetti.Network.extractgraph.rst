spaghetti.Network.extractgraph
==============================

.. currentmodule:: spaghetti

.. automethod:: Network.extractgraph