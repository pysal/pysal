spaghetti.Network.allneighbordistances
======================================

.. currentmodule:: spaghetti

.. automethod:: Network.allneighbordistances