spaghetti.Network.snapobservations
==================================

.. currentmodule:: spaghetti

.. automethod:: Network.snapobservations