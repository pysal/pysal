spaghetti.dijkstra
==================

.. currentmodule:: spaghetti

.. autofunction:: dijkstra