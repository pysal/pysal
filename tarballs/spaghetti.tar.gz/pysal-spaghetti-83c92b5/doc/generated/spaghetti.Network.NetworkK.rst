spaghetti.Network.NetworkK
==========================

.. currentmodule:: spaghetti

.. automethod:: Network.NetworkK