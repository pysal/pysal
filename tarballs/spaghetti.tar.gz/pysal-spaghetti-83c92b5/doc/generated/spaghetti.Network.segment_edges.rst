spaghetti.Network.segment\_edges
================================

.. currentmodule:: spaghetti

.. automethod:: Network.segment_edges