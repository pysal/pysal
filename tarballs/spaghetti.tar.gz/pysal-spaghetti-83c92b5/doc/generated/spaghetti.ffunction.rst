spaghetti.ffunction
===================

.. currentmodule:: spaghetti

.. autofunction:: ffunction