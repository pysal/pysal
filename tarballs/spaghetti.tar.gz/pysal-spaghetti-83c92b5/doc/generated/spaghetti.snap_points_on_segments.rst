spaghetti.snap\_points\_on\_segments
====================================

.. currentmodule:: spaghetti

.. autofunction:: snap_points_on_segments