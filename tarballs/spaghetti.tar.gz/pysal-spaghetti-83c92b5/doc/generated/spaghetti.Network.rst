spaghetti.Network
=================

.. currentmodule:: spaghetti

.. autoclass:: Network

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~Network.NetworkF
      ~Network.NetworkG
      ~Network.NetworkK
      ~Network.__init__
      ~Network.allneighbordistances
      ~Network.compute_distance_to_nodes
      ~Network.contiguityweights
      ~Network.count_per_edge
      ~Network.distancebandweights
      ~Network.enum_links_node
      ~Network.extractgraph
      ~Network.loadnetwork
      ~Network.nearestneighbordistances
      ~Network.node_distance_matrix
      ~Network.savenetwork
      ~Network.segment_edges
      ~Network.simulate_observations
      ~Network.snapobservations
   
   

   
   
   