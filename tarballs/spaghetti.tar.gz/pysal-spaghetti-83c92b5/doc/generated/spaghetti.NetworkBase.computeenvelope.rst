spaghetti.NetworkBase.computeenvelope
=====================================

.. currentmodule:: spaghetti

.. automethod:: NetworkBase.computeenvelope