spaghetti.Network.contiguityweights
===================================

.. currentmodule:: spaghetti

.. automethod:: Network.contiguityweights