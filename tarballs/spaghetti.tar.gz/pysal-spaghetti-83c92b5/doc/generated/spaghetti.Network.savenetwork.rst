spaghetti.Network.savenetwork
=============================

.. currentmodule:: spaghetti

.. automethod:: Network.savenetwork