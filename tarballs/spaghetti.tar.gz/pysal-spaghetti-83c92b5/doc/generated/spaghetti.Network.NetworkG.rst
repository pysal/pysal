spaghetti.Network.NetworkG
==========================

.. currentmodule:: spaghetti

.. automethod:: Network.NetworkG