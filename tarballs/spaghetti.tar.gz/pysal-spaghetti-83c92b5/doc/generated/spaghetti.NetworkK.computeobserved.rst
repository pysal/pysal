spaghetti.NetworkK.computeobserved
==================================

.. currentmodule:: spaghetti

.. automethod:: NetworkK.computeobserved