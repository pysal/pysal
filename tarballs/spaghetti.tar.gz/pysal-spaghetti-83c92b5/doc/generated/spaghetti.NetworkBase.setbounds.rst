spaghetti.NetworkBase.setbounds
===============================

.. currentmodule:: spaghetti

.. automethod:: NetworkBase.setbounds