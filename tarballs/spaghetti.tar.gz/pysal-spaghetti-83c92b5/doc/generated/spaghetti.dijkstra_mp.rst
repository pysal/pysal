spaghetti.dijkstra\_mp
======================

.. currentmodule:: spaghetti

.. autofunction:: dijkstra_mp