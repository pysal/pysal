spaghetti.NetworkK
==================

.. currentmodule:: spaghetti

.. autoclass:: NetworkK

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NetworkK.__init__
      ~NetworkK.computeenvelope
      ~NetworkK.computeobserved
      ~NetworkK.computepermutations
      ~NetworkK.setbounds
      ~NetworkK.validatedistribution
   
   

   
   
   