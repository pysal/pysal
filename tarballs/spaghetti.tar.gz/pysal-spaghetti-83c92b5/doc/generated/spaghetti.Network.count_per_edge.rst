spaghetti.Network.count\_per\_edge
==================================

.. currentmodule:: spaghetti

.. automethod:: Network.count_per_edge