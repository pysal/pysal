spaghetti.kfunction
===================

.. currentmodule:: spaghetti

.. autofunction:: kfunction