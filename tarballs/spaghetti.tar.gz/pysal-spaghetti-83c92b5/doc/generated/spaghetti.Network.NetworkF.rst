spaghetti.Network.NetworkF
==========================

.. currentmodule:: spaghetti

.. automethod:: Network.NetworkF