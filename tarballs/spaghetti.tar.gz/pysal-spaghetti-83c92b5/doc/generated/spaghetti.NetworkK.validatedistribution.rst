spaghetti.NetworkK.validatedistribution
=======================================

.. currentmodule:: spaghetti

.. automethod:: NetworkK.validatedistribution