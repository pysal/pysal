spaghetti.Network.node\_distance\_matrix
========================================

.. currentmodule:: spaghetti

.. automethod:: Network.node_distance_matrix