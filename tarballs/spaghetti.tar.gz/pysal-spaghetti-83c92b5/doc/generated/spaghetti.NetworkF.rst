spaghetti.NetworkF
==================

.. currentmodule:: spaghetti

.. autoclass:: NetworkF

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NetworkF.__init__
      ~NetworkF.computeenvelope
      ~NetworkF.computeobserved
      ~NetworkF.computepermutations
      ~NetworkF.setbounds
      ~NetworkF.validatedistribution
   
   

   
   
   