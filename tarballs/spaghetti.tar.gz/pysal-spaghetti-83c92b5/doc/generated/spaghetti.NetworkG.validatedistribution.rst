spaghetti.NetworkG.validatedistribution
=======================================

.. currentmodule:: spaghetti

.. automethod:: NetworkG.validatedistribution