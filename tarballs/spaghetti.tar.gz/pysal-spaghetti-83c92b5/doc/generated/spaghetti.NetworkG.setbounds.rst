spaghetti.NetworkG.setbounds
============================

.. currentmodule:: spaghetti

.. automethod:: NetworkG.setbounds