spaghetti.Network.compute\_snap\_dist
=====================================

.. currentmodule:: spaghetti

.. automethod:: Network.compute_snap_dist