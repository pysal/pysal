spaghetti.NetworkBase
=====================

.. currentmodule:: spaghetti

.. autoclass:: NetworkBase

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~NetworkBase.__init__
      ~NetworkBase.computeenvelope
      ~NetworkBase.setbounds
      ~NetworkBase.validatedistribution
   
   

   
   
   