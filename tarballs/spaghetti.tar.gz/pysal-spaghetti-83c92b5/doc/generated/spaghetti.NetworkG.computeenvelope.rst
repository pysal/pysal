spaghetti.NetworkG.computeenvelope
==================================

.. currentmodule:: spaghetti

.. automethod:: NetworkG.computeenvelope