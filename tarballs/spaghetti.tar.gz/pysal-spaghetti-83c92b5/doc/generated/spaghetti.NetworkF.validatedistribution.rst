spaghetti.NetworkF.validatedistribution
=======================================

.. currentmodule:: spaghetti

.. automethod:: NetworkF.validatedistribution