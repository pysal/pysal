spaghetti.NetworkBase.validatedistribution
==========================================

.. currentmodule:: spaghetti

.. automethod:: NetworkBase.validatedistribution