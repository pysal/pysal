spaghetti.Network.loadnetwork
=============================

.. currentmodule:: spaghetti

.. automethod:: Network.loadnetwork