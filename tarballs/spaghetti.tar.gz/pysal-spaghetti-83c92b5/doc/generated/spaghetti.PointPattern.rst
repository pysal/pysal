spaghetti.PointPattern
======================

.. currentmodule:: spaghetti

.. autoclass:: PointPattern

   
   .. automethod:: __init__

   
   .. rubric:: Methods

   .. autosummary::
   
      ~PointPattern.__init__
   
   

   
   
   