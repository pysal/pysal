spaghetti.NetworkK.computepermutations
======================================

.. currentmodule:: spaghetti

.. automethod:: NetworkK.computepermutations