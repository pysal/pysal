spaghetti.Network.compute\_distance\_to\_nodes
==============================================

.. currentmodule:: spaghetti

.. automethod:: Network.compute_distance_to_nodes