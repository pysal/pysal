spaghetti.NetworkF.computeenvelope
==================================

.. currentmodule:: spaghetti

.. automethod:: NetworkF.computeenvelope