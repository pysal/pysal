spaghetti.compute\_length
=========================

.. currentmodule:: spaghetti

.. autofunction:: compute_length