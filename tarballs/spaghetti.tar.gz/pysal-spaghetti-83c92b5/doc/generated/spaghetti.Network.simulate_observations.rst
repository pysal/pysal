spaghetti.Network.simulate\_observations
========================================

.. currentmodule:: spaghetti

.. automethod:: Network.simulate_observations