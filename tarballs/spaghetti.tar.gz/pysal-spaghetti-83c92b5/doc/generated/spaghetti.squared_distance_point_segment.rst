spaghetti.squared\_distance\_point\_segment
===========================================

.. currentmodule:: spaghetti

.. autofunction:: squared_distance_point_segment