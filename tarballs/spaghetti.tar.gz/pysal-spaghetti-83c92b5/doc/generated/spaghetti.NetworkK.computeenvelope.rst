spaghetti.NetworkK.computeenvelope
==================================

.. currentmodule:: spaghetti

.. automethod:: NetworkK.computeenvelope