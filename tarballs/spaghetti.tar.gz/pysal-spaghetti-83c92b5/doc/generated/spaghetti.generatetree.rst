spaghetti.generatetree
======================

.. currentmodule:: spaghetti

.. autofunction:: generatetree