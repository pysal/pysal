# Changes

Version 1.1.1 (2018-10-31)

We closed a total of 5 issues (enhancements and bug fixes) through 2 pull requests, since our last release on 2018-10-30.

## Issues Closed
  - removed .txt format CHANGELOG (#129)
  - rel: v1.1.0 -- Adjusting CHANGELOG.md prior to tagged release (#128)
  - prepare new release for pypi -- v1.1.0 (#57)

## Pull Requests
  - removed .txt format CHANGELOG (#129)
  - rel: v1.1.0 -- Adjusting CHANGELOG.md prior to tagged release (#128)

The following individuals contributed to this release:

  - James Gaboardi